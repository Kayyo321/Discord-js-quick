const fs = require('fs')

module.exports = disjs

function disjs() {

        const disjs = fs.readFileSync(`${__dirname}/app.js`)

        const fileName = process.argv[2]

        fs.writeFileSync(`${process.cwd()}/app.js`,disjs)

        console.log('installing app.js...')

        fs.writeFileSync(`${process.cwd()}/${fileName}`, "BOT_TOKEN= //Put your discord bot token in front of the equals sign! No spaces in between, no nuthin! (start token from the character, [11], line 1)")

        console.log('installing .env...')
}


disjs()

console.log('Remember is rename the file, "undefined", to be .env!')
